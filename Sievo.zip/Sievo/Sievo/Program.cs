﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ReadLogs
{
    class Program
    {
        static void Main(string[] args)
        {
            Input inputData = new Input();

            Console.Write("Please Enter Value of Threshold ");
            int output;
            int.TryParse(Console.ReadLine(), out output);
            inputData.Threshold = output;
          
            Console.Write("Please Enter File Name ");
            inputData.fileName = Console.ReadLine();
          
            Console.Write("Please Enter Server Name For Logged Errors ");
            inputData.searchString = Console.ReadLine();

            inputData.ReadFile();
            
        }
    }

    class Input
    {
        public int Threshold { get; set; }
        public string fileName { get; set; }
        public string searchString { get; set; }
        public string channel { get; set; }

        public void ReadFile()
        {
            var threshold = this.Threshold;
            var searchString = this.searchString;
            StreamReader myReader = new StreamReader(this.fileName);
            string line = "";
            int counts = 0;
            while (line != null)
            {
                line = myReader.ReadLine();
                var read = Convert.ToString(line);
                String.IsNullOrEmpty(line);
                if (!string.IsNullOrEmpty(line) && line.Contains(this.searchString))
                    counts++;
            }
            if (threshold <= counts)
            {
                Console.Write("Since logged errors of Server " + this.searchString + " are " + counts + " and more than threshold value " + this.Threshold + ". Please enter Slack Channel for notifications ");
                this.channel = Console.ReadLine();
                Console.WriteLine("Notification is being posted to channel #" + this.channel + " of slack");
                myReader.Close();

                string token = Environment.GetEnvironmentVariable("webhook");
                string userName = Environment.GetEnvironmentVariable("slack_user_name");
                string urlWithAccessToken = token;
                SlackClient client = new SlackClient(urlWithAccessToken);

                client.PostMessage(username: userName,
                text: "Error logged " + counts + " times which is more than given threashold "+ this.Threshold + " of server "+ this.searchString,
                channel: this.channel);
                Console.WriteLine("Notification is posted successfuly to channel #"+ this.channel + " of slack");
            }
            else
            {
                Console.WriteLine("Congrats! Logged errors "+ counts +" are less than threshold " + this.Threshold);

            }

            Console.ReadLine();
        }
       
    }
    }
